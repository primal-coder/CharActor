from ._charactor import dicts
from ._charactor import create, BaseCharacters, character_bank
from . import _entity